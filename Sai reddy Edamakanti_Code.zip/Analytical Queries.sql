
# Query 1 — View Dataset


SELECT *
FROM grocery_grocery_reviews_parquet
LIMIT 10;

# Query 2 — Count Records

SELECT COUNT(*)
FROM grocery_grocery_reviews_parquet;

# Query 3 — Average Rating

SELECT AVG(rating)
FROM grocery_grocery_reviews_parquet;


# Query 4 — Top Products

SELECT parent_asin,
COUNT(*) AS review_count
FROM grocery_grocery_reviews_parquet
GROUP BY parent_asin
ORDER BY review_count DESC
LIMIT 10;


# Query 5 — Top review titles

SELECT title, rating
FROM grocery_grocery_reviews_parquet
LIMIT 20;