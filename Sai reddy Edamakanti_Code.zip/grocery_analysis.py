# Import required PySpark libraries and SQL functions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lower, length, when, count, avg, desc


# Create Spark Session for distributed big data processing
# The Spark session enables Apache Spark to run on the Amazon EMR cluster.

spark = SparkSession.builder \
    .appName("Amazon Grocery Review Big Data Analytics") \
    .config("spark.sql.shuffle.partitions", "8") \
    .getOrCreate()


# Define the location of input and output files in Amazon S3
# The raw dataset is stored in S3, and the processed output
# will also be saved back into S3 in Parquet format.

input_path = "s3://lds7005-s3-sai/raw-data/Grocery_and_Gourmet_Food.jsonl"
output_path = "s3://lds7005-s3-sai/processed-data/grocery_reviews_parquet/"


# Load the grocery review dataset from Amazon S3 into a Spark DataFrame
# Spark automatically distributes the dataset across cluster nodes.

print("===== LOADING DATASET FROM S3 =====")
df = spark.read.json(input_path)


# Display the dataset schema to verify column names and data types
# before performing preprocessing operations.

print("===== DATASET SCHEMA =====")
df.printSchema()


# Count the total number of records in the raw dataset
# to confirm successful ingestion into Spark.

print("===== TOTAL RAW RECORDS =====")
print(df.count())


# Select only the required columns for analysis
# Data type conversion is applied where necessary.
# Records with missing values in important fields are removed.

clean_df = df.select(
    col("rating").cast("double").alias("rating"),
    col("title"),
    col("text"),
    col("timestamp"),
    col("asin"),
    col("parent_asin"),
    col("user_id"),
    col("helpful_vote").cast("int").alias("helpful_vote"),
    col("verified_purchase")
).dropna(subset=["rating", "text", "user_id", "parent_asin"])


# Convert review text into lowercase format
# This helps maintain consistency during text analysis.

clean_df = clean_df.withColumn("clean_text", lower(col("text")))


# Create a new feature called review_length
# This calculates the number of characters in each review.

clean_df = clean_df.withColumn(
    "review_length",
    length(col("clean_text"))
)


# Perform sentiment classification based on review ratings
# Ratings greater than or equal to 4 are considered positive,
# rating equal to 3 is considered neutral,
# and ratings below 3 are considered negative.

clean_df = clean_df.withColumn(
    "sentiment_label",
    when(col("rating") >= 4, "positive")
    .when(col("rating") == 3, "neutral")
    .otherwise("negative")
)


# Display the total number of records after preprocessing
# and data cleaning operations.

print("===== CLEANED RECORDS =====")
print(clean_df.count())


# Analyze the distribution of customer ratings
# This helps identify overall customer satisfaction trends.

print("===== RATING DISTRIBUTION =====")
clean_df.groupBy("rating") \
    .count() \
    .orderBy("rating") \
    .show()


# Analyze the distribution of sentiment categories
# This identifies the number of positive, neutral,
# and negative customer reviews.

print("===== SENTIMENT DISTRIBUTION =====")
clean_df.groupBy("sentiment_label") \
    .count() \
    .show()


# Perform verified purchase analysis
# This section compares verified and non-verified purchases
# based on review count, average rating, and review length.

print("===== VERIFIED PURCHASE ANALYSIS =====")
clean_df.groupBy("verified_purchase").agg(
    count("*").alias("total_reviews"),
    avg("rating").alias("average_rating"),
    avg("review_length").alias("average_review_length")
).show()


# Identify the most reviewed grocery products
# The query calculates total reviews and average ratings
# for each product.

print("===== TOP REVIEWED PRODUCTS =====")
clean_df.groupBy("parent_asin").agg(
    count("*").alias("review_count"),
    avg("rating").alias("average_rating")
).orderBy(desc("review_count")).show(20)


# Save the processed dataset into Amazon S3 in Parquet format
# Parquet provides compressed columnar storage,
# faster querying performance, and reduced storage costs.

print("===== SAVING CLEANED DATA TO PARQUET =====")
clean_df.write.mode("overwrite").parquet(output_path)


# Stop the Spark session after successful execution
# This releases cluster resources and completes the job.

print("===== JOB COMPLETED SUCCESSFULLY =====")
spark.stop()